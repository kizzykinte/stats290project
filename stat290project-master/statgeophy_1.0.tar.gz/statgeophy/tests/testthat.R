library(testthat)
library(statgeophy)

test_check("statgeophy")
