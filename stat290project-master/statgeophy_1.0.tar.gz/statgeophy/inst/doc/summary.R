## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(statgeophy)

## ---- eval = FALSE-------------------------------------------------------
#  #Default uses datalength = 1000 input points and model = shearRange
#  df <- generateData()
#  
#  #Different arguments of generateData function
#  df <- generateData(datalength = 1000, modelfn = shearRange, userdata = NULL,
#                           v_mean = list(36, 36, 1, 1, 0.3),
#                           v_sd = list(10, 10, 0.4, 0.4, 0.2), visualize = FALSE )
#  
#  #For generating a compositeShear model output
#  df <- generateData(modelfn = compositeShear, v_mean = list(36, 45, 36, 45, 1, 0.4, 0.25),
#      v_sd = list(10, 10, 10, 10, 0.5, 0.1, 0.1))
#  
#  #User-defined models can be passed to this function too e.g if the function is myModel and
#  #user wants to generate data. User knows the number of inputs is needed by his function. If he
#  #wants to generate the inputs, he will pass the appropriate lengths of v_mean and v_sd (making sure
#  #length(v_mean) = length(v_sd)). e.g the number of inputs is 3
#  
#  df <- generateData(modelfn = myModel, v_mean = list(10, 20, 0.5), v_sd = list(2, 4, 0.2))
#  
#  #Alternatively user can pass a userdata dataframe with columns which are inputs. He can again
#  #chose default shearRange or chose compositeShear or his own model to create an output
#  v_mean = list(36, 36, 1, 1, 0.3)
#  v_sd = list(10, 10, 0.4, 0.4, 0.2)
#  myDataFrame <- mapply(rnorm, 2000, v_mean, v_sd)
#  df <- generateData(userdata = myDataFrame) #For shearRange (make sure the number of inputs = 5)
#  df <- generateData(modelfn = compositeShear, userdata = myDataFrame) #For compositeShear
#  df <- generateData(modelFn = myModel, userdata = myDataFrame) # For user model
#  ########
#  #DO NOT use quotes around the function names. "shearRange" is wrong. Use shearRange/compositeShear/myModel.
#  ########
#  
#  #To visualize the data after the modelling (since some filters are applied during the modelling and
#  #some of the original inputs values are dropped), if visualize=TRUE, the inputs will be plotted against
#  #each other using pairs function
#  
#  df <- generateData(visualize=TRUE)
#  

## ---- eval = FALSE-------------------------------------------------------
#  #The dataframe produced can be input into modelFitting to do different model fits
#  #The default used is linear regression. To plot the predictor importance
#  #set plotPredImp = TRUE
#  m <- modelFitting(df, modelFit = "lm", plotPredImp = FALSE)
#  
#  #Values of modelFit = "lm", "rf", "gb" and "all"
#  #modelFit = "all" computes all three model fits
#  m <- modelFitting(df, modelFit = "all", plotPredImp = FALSE)

## ------------------------------------------------------------------------
#Plotting
df <- suppressMessages(generateData())
m <- modelFitting(df, modelFit = "all", plotPredImp = TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  #Result visualization examples are shiny apps.
#  
#  #Inputs: Data length, sliders to change the mean and sd for the rnorm
#  #generation of the data.
#  
#  #Output: It has 3 tabs: Predictor Importance,
#  #Test vs Predicted values, summary of the 3 fits.
#  
#  #For shearRange modelling results for all 3 fits use
#  statgeophy::shinyShearRange()
#  
#  #For compositeShear
#  statgeophy::shinyCompositeShear()

